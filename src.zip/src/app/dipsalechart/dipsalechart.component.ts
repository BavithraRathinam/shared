import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Data } from '../../app/Data';
import { Chart } from 'chart.js'; 

@Component({
  selector: 'app-dipsalechart',
  templateUrl: './dipsalechart.component.html',
  styleUrls: ['./dipsalechart.component.css']
})
export class DipsalechartComponent implements OnInit {

  
  url ='http://localhost:8082/sales/dip';  
  
  dipSale=[];
  dipAccessory=[];
  
  chart = []; 
   constructor(private httpClient: HttpClient) { }  

  ngOnInit() {
     
    this.httpClient.get(this.url).subscribe((result: Data[]) => {  
      result.forEach(x => {  
        this.dipAccessory.push(x.dipAccessory);  
        this.dipSale.push(x.dipSale);
       
        
  
      });  
      this  
      this.chart = new Chart('dipsale', {  
        type: 'pie',  

        options: {
          responsive: true,
          title: {
            display: true,
            text: 'Dip Accessory Sales from Last 3 Years'
          },
        },






        data: {  
          labels: this.dipAccessory,  
          datasets: [  
            {  
              type: 'pie',
          
            data: this.dipSale,
            backgroundColor: ["red","yellow","green","orange","blue","purple","black","orange",
             "purple","blue","purple"],
              borderColor: 'rgba(0,0,0,1)',
            fill: false,
            }  ,

            // {
            //   type: 'bar',
            //   label: 'UAE',
            //   data: this.cou2,
            //   backgroundColor: 'rgba(0,255,0,0.7)',
            //   borderColor: 'rgba(0,255,255,1)',
            //   fill: false,
            // },

            // {
            //   type: 'pie',
            //   label: 'US',
            //   data: this.saleyear,
            //   backgroundColor: 'rgba(255,0,0,1)',
            //   borderColor: 'rgba(0,0,255,1)',
            //   fill: false,
            // }
          

          ]  
        },  


      });  

  })
}
}
