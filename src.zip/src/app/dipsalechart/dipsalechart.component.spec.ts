import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DipsalechartComponent } from './dipsalechart.component';

describe('DipsalechartComponent', () => {
  let component: DipsalechartComponent;
  let fixture: ComponentFixture<DipsalechartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DipsalechartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DipsalechartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
