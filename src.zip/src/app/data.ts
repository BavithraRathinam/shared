export class Data {
    // uae:string;
    // sale_year:string;
    // india:string;
    // us:string;
    highSaleDetails:string;
    maxSale:number;
    lowSaleDetails:string;
    minSale:number;
    dipAccessory:String;
    dipSale:number;
    year:string;
    uae:number;
    usa:number;
    uk:number;
    Year:number;
    Sales:number;


  

}
