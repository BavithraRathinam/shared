import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';  
import { HttpClient } from '@angular/common/http';  
import { Data } from '../../app/Data';

@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})

export class LoginsuccessComponent implements OnInit {
  url ='http://localhost:8082/sales/high';  
  highSaleDetails=[];
  minSale=[];
  lowSaleDetails=[];
  maxSale=[];
  dipAccessory=[];
  dipSale=[];
  year=[];
  uae=[];
  usa=[];
  uk=[];
  chart = []; 
   constructor(private httpClient: HttpClient) { }  
  ngOnInit() {  
    this.httpClient.get(this.url).subscribe((result: Data[]) => {  
      result.forEach(x => {  
        this.highSaleDetails.push(x.highSaleDetails);  
        this.maxSale.push(x.maxSale);
        //this.max.push(x.max);
        //this.model.push(x.model);
        
  
      });  
      this  
      this.chart = new Chart('highsale', {  
        type: 'pie',  

        options: {
          responsive: true,
          title: {
            display: true,
            text: 'High Sale Vehicle and Accessory'
          },
        },






        data: {  
          labels: this.highSaleDetails,  
          datasets: [  
            {  
              type: 'pie',
          
            data: this.maxSale,
            backgroundColor: ["red","yellow","green","orange","blue","purple","red","orange",
            "yellow","green","blue","purple"],
              borderColor: 'rgba(0,0,0,1)',
            fill: false,
            }  ,

            // {
            //   type: 'bar',
            //   label: 'UAE',
            //   data: this.cou2,
            //   backgroundColor: 'rgba(0,255,0,0.7)',
            //   borderColor: 'rgba(0,255,255,1)',
            //   fill: false,
            // },

            // {
            //   type: 'pie',
            //   label: 'US',
            //   data: this.saleyear,
            //   backgroundColor: 'rgba(255,0,0,1)',
            //   borderColor: 'rgba(0,0,255,1)',
            //   fill: false,
            // }
          

          ]  
        },  


      });  

  })
}
   /////////////////////////////////////////////////////////////////////////////////////////////////////////
  // constructor(private httpClient: HttpClient) { }  
  // ngOnInit() {  
  //   this.httpClient.get(this.url).subscribe((result: Data[]) => {  
  //     result.forEach(x => {  
  //       this.sale.push(x.sale_year);  
  //       this.cou1.push(x.india);
  //       this.cou2.push(x.uae);
  //       this.cou3.push(x.us);
  
  //     });  
  //     this  
  //     this.chart = new Chart('sale5', {  
  //       type: 'bar',  

  //       options: {
  //         responsive: true,
  //         title: {
  //           display: true,
  //           text: 'Sales for Past 5Years'
  //         },
  //       },






  //       data: {  
  //         labels: this.sale,  
  //         datasets: [  
  //           {  
  //             type: 'bar',
  //           label: 'India',
  //           data: this.cou1,
  //           backgroundColor: 'rgba(255,0,255,0.9)',
  //             borderColor: 'rgba(255,255,255,0.9)',
  //           fill: false,
  //           }  ,

  //           {
  //             type: 'bar',
  //             label: 'UAE',
  //             data: this.cou2,
  //             backgroundColor: 'rgba(0,255,0,0.7)',
  //             borderColor: 'rgba(0,255,255,1)',
  //             fill: false,
  //           },

  //           {
  //             type: 'bar',
  //             label: 'US',
  //             data: this.cou3,
  //             backgroundColor: 'rgba(255,0,0,1)',
  //             borderColor: 'rgba(0,0,255,1)',
  //             fill: false,
  //           }
          

  //         ]  
  //       },  


  //     });  

  // })
//}
///////////////////////////////////////////////////////////////////////////////////////////////////////
}


