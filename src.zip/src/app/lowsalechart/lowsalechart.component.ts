import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';  
import { HttpClient } from '@angular/common/http';  
import { Data } from '../../app/Data';

@Component({
  selector: 'app-lowsalechart',
  templateUrl: './lowsalechart.component.html',
  styleUrls: ['./lowsalechart.component.css']
})
export class LowsalechartComponent implements OnInit {

  url ='http://localhost:8082/sales/low';  
  
  minSale=[];
  lowSaleDetails=[];
  
  chart = []; 
   constructor(private httpClient: HttpClient) { }  

  ngOnInit() {
     
    this.httpClient.get(this.url).subscribe((result: Data[]) => {  
      result.forEach(x => {  
        this.lowSaleDetails.push(x.lowSaleDetails);  
        this.minSale.push(x.minSale);
       
        
  
      });  
      this  
      this.chart = new Chart('lowsale', {  
        type: 'pie',  

        options: {
          responsive: true,
          title: {
            display: true,
            text: 'Low Sale Vehicle and Accessory'
          },
        },






        data: {  
          labels: this.lowSaleDetails,  
          datasets: [  
            {  
              type: 'pie',
          
            data: this.minSale,
            backgroundColor: ["red","yellow","green","orange","blue","purple","red","orange",
            "yellow","green","blue","purple"],
              borderColor: 'rgba(0,0,0,1)',
            fill: false,
            }  ,

            // {
            //   type: 'bar',
            //   label: 'UAE',
            //   data: this.cou2,
            //   backgroundColor: 'rgba(0,255,0,0.7)',
            //   borderColor: 'rgba(0,255,255,1)',
            //   fill: false,
            // },

            // {
            //   type: 'pie',
            //   label: 'US',
            //   data: this.saleyear,
            //   backgroundColor: 'rgba(255,0,0,1)',
            //   borderColor: 'rgba(0,0,255,1)',
            //   fill: false,
            // }
          

          ]  
        },  


      });  

  })
}
  }


