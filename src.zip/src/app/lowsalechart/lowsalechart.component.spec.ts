import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LowsalechartComponent } from './lowsalechart.component';

describe('LowsalechartComponent', () => {
  let component: LowsalechartComponent;
  let fixture: ComponentFixture<LowsalechartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LowsalechartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LowsalechartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
