import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule } from '@angular/forms';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { SearchComponent } from './search/search.component';
import { LowsalechartComponent } from './lowsalechart/lowsalechart.component';
import { DipsalechartComponent } from './dipsalechart/dipsalechart.component';
import { PastsalechartComponent } from './pastsalechart/pastsalechart.component';
import { SearchchartComponent } from './searchchart/searchchart.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    LoginsuccessComponent,
    SearchComponent,
    LowsalechartComponent,
    DipsalechartComponent,
    PastsalechartComponent,
    SearchchartComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
