import { element } from 'protractor';
//import { SearchService } from './../search.service';
import { Component, ViewChild, ElementRef } from '@angular/core';
import { Router, RouterModule } from '@angular/router';  
import { HttpClient } from '@angular/common/http';  
import { Data } from '../../app/Data';
import * as jsPDF from 'jspdf';

// import { FormGroup, FormControl } from '@angular/forms';


 @Component({
   selector: 'app-search',
  templateUrl: './search.component.html',
   styleUrls: ['./search.component.css']
 })
 export class SearchComponent{
  selectedSeries = 0;
  selectedYear = 0;
   
  year = [];
  code = [];
   
   
  onSelectSeries(series_id: number) {
  this.selectedSeries = series_id;
  this.selectedYear = 0;
  this.code = [];
  this.year = this.getYear().filter((item) => {
  return item.series_id === Number(series_id)
  });
  }
   
  onSelectYear(year_id: number) {
  this.selectedYear = year_id;
  this.code = this.getCode().filter((item) => {
  return item.year_id === Number(year_id)
  });
  }
   
  getSeries() {
  return [
  { id: 1, name: 'fortuner' },
  { id: 2, name: 'yaris' },
  { id: 3, name: 'camry' },
  { id: 4, name: 'innova' },
  { id: 5, name: 'glanza' },
  { id: 6, name: 'etios' }
  ];
  }
   
  getYear() {
  return [
  { id: 1, series_id: 1, name: '2015' },
  { id: 2, series_id: 1, name: '2016' },
  { id: 3, series_id: 1, name: '2017' },
  { id: 4, series_id: 1, name: '2018' },
  { id: 5, series_id: 1, name: '2019' },
  { id: 6, series_id: 2, name: '2015' },
  { id: 7, series_id: 2, name: '2016' },
  { id: 8, series_id: 2, name: '2017' },
  { id: 9, series_id: 2, name: '2018' },
  { id: 10, series_id: 2, name: '2019' },
  { id: 11, series_id: 3, name: '2015' },
  { id: 12, series_id: 3, name: '2016' },
  { id: 13, series_id: 3, name: '2017' },
  { id: 14, series_id: 3, name: '2018' },
  { id: 15, series_id: 3, name: '2019' },
  { id: 16, series_id: 4, name: '2015' },
  { id: 17, series_id: 4, name: '2016' },
  { id: 18, series_id: 4, name: '2017' },
  { id: 19, series_id: 4, name: '2018' },
  { id: 20, series_id: 4, name: '2019' },
  { id: 21, series_id: 5, name: '2015' },
  { id: 22, series_id: 5, name: '2016' },
  { id: 23, series_id: 5, name: '2017' },
  { id: 24, series_id: 5, name: '2018' },
  { id: 25, series_id: 5, name: '2019' },
  { id: 26, series_id: 6, name: '2015' },
  { id: 27, series_id: 6, name: '2016' },
  { id: 28, series_id: 6, name: '2017' },
  { id: 29, series_id: 6, name: '2018' },
  { id: 30, series_id: 6, name: '2019' },


  
  
   

 
  ]
  }
   
  getCode() {
  return [
    { id: 1, year_id: 1, name: 'LXI' },
{ id: 2, year_id: 1, name: 'LDI' },
{ id: 3, year_id: 1, name: 'LZI' },
{ id: 4, year_id: 2, name: 'LXI' },
{ id: 5, year_id: 2, name: 'LDI' },
{ id: 6, year_id: 2, name: 'LZI' },
{ id: 7, year_id: 3, name: 'LXI' },
{ id: 8, year_id: 3, name: 'LDI' },
{ id: 9, year_id: 3, name: 'LZI' },
{ id: 10, year_id: 4, name: 'LXI' },
{ id: 11, year_id: 4, name: 'LDI' },
{ id: 12, year_id: 4, name: 'LZI' },
{ id: 13, year_id: 5, name: 'LXI' },
{ id: 14, year_id: 5, name: 'LDI' },
{ id: 15, year_id: 5, name: 'LZI' },
{ id: 16, year_id: 6, name: 'LXI' },
{ id: 17, year_id: 6, name: 'LDI' },
{ id: 18, year_id: 6, name: 'LZI' },
{ id: 19, year_id: 7, name: 'LXI' },
{ id: 20, year_id: 7, name: 'LDI' },
{ id: 21, year_id: 7, name: 'LZI' },
{ id: 22, year_id: 8, name: 'LXI' },
{ id: 23, year_id: 8, name: 'LDI' },
{ id: 24, year_id: 8, name: 'LZI' },
{ id: 25, year_id: 9, name: 'LXI' },
{ id: 26, year_id: 9, name: 'LDI' },
{ id: 27, year_id: 9, name: 'LZI' },
{ id: 28, year_id: 10, name: 'LXI' },
{ id: 29, year_id: 10, name: 'LDI' },
{ id: 30, year_id: 10, name: 'LZI'},
{ id: 31, year_id: 11, name: 'LXI' },
{ id: 32, year_id: 11, name: 'LDI' },
{ id: 33, year_id: 11, name: 'LZI' },
{ id: 34, year_id: 12, name: 'LXI' },
{ id: 35, year_id: 12, name: 'LDI' },
{ id: 36, year_id: 12, name: 'LZI' },
{ id: 37, year_id: 13, name: 'LXI' },
{ id: 38, year_id: 13, name: 'LDI' },
{ id: 39, year_id: 13, name: 'LZI' },
{ id: 40, year_id: 14, name: 'LXI' },
{ id: 41, year_id: 14, name: 'LDI' },
{ id: 42, year_id: 14, name: 'LZI' },
{ id: 43, year_id: 15, name: 'LXI' },
{ id: 44, year_id: 15, name: 'LDI' },
{ id: 45, year_id: 15, name: 'LZI' },
{ id: 46, year_id: 16, name: 'LXI' },
{ id: 47, year_id: 16, name: 'LDI' },
{ id: 48, year_id: 16, name: 'LZI' },
{ id: 49, year_id: 17, name: 'LXI' },
{ id: 50, year_id: 17, name: 'LDI' },
{ id: 51, year_id: 17, name: 'LZI' },
{ id: 52, year_id: 18, name: 'LXI' },
{ id: 53, year_id: 18, name: 'LDI' },
{ id: 54, year_id: 18, name: 'LZI' },
{ id: 55, year_id: 19, name: 'LXI' },
{ id: 56, year_id: 19, name: 'LDI' },
{ id: 57, year_id: 19, name: 'LZI' },
{ id: 58, year_id: 20, name: 'LXI' },
{ id: 59, year_id: 20, name: 'LDI' },
{ id: 60, year_id: 20, name: 'LZI' },
{ id: 61, year_id: 21, name: 'LXI' },
{ id: 62, year_id: 21, name: 'LDI' },
{ id: 63, year_id: 21, name: 'LZI' },
{ id: 64, year_id: 22, name: 'LXI' },
{ id: 65, year_id: 22, name: 'LDI' },
{ id: 66, year_id: 22, name: 'LZI' },
{ id: 67, year_id: 23, name: 'LXI' },
{ id: 68, year_id: 23, name: 'LDI' },
{ id: 69, year_id: 23, name: 'LZI' },
{ id: 70, year_id: 24, name: 'LXI' },
{ id: 71, year_id: 24, name: 'LDI' },
{ id: 72, year_id: 24, name: 'LZI' },
{ id: 73, year_id: 25, name: 'LXI' },
{ id: 74, year_id: 25, name: 'LDI' },
{ id: 75, year_id: 25, name: 'LZI' },
{ id: 76, year_id: 26, name: 'LXI' },
{ id: 77, year_id: 26, name: 'LDI' },
{ id: 78, year_id: 26, name: 'LZI' },
{ id: 79, year_id: 27, name: 'LXI' },
{ id: 80, year_id: 27, name: 'LDI' },
{ id: 81, year_id: 27, name: 'LZI' },
{ id: 82, year_id: 28, name: 'LXI' },
{ id: 83, year_id: 28, name: 'LDI' },
{ id: 84, year_id: 28, name: 'LZI' },
{ id: 85, year_id: 29, name: 'LXI' },
{ id: 86, year_id: 29, name: 'LDI' },
{ id: 87, year_id: 29, name: 'LZI' },
{ id: 88, year_id: 30, name: 'LXI' },
{ id: 89, year_id: 30, name: 'LDI' },
{ id: 90, year_id: 30, name: 'LZI' },
   
  ]
  }

  @ViewChild('content') content: ElementRef;

  public downloadPDF(){

    let doc = new jsPDF();

    let specialElementHandlers = {

      '#editor': function(element, renderer){
        return true;
      }
    };

    let content = this.content.nativeElement;

    doc.fromHTML(content.innerHTML, 15, 15, {
      'width':190,
      'elementHandlers': specialElementHandlers
    });

    doc.save('test.pdf');

  }


  

//   searchForm: FormGroup;

//   series:{};
//   modelYear:{};
//   modelcode:{};

//   constructor(private searchService:SearchService) { }

//   ngOnInit() {


//     this.searchService.getSeries().subscribe(
//       data => this.series = data
//     );
  

//   this.searchForm = new FormGroup({
//     series: new FormControl(''),
//     model: new FormControl(''),
//     modelcode: new FormControl(''),
//     modelYear: new FormControl('')
//   });SearchService
// }

// onChangeSeries(seriesId: number) {
//   if (seriesId) {
//     this.searchService.getModelYear(seriesId).subscribe(
//       data => {
//         this.series = data;
//         this.modelYear = null;
//         this.modelcode=null;
        
//       }
//     );
//   } else {
//         this.series = null;
//         this.modelYear = null;
//         this.modelcode=null;
//   }
// }






// onChangeModelYear(modelyearId: number) {
//   if (modelyearId) {
//     this.searchService.getModelCode(modelyearId).subscribe(
//       data => {
        
//         this.modelYear = data;
//         this.modelcode=null;
        
//       }
//     );
//   } else {
       
//         this.modelYear = null;
//         this.modelcode=null;
//   }
// }







 }
