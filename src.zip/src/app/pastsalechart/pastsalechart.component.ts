import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Data } from '../../app/Data';
import { Chart } from 'chart.js'; 

@Component({
  selector: 'app-pastsalechart',
  templateUrl: './pastsalechart.component.html',
  styleUrls: ['./pastsalechart.component.css']
})
export class PastsalechartComponent implements OnInit {

  
  url ='http://localhost:8082/sales/past';  
  
  year=[];
  uae=[];
  usa=[]
  uk=[]
  
  chart = []; 
   constructor(private httpClient: HttpClient) { }  

  ngOnInit() {
     
    this.httpClient.get(this.url).subscribe((result: Data[]) => {  
      result.forEach(x => {  
        this.year.push(x.year);  
        this.uae.push(x.uae);
        this.usa.push(x.usa);
        this.uk.push(x.uk);
       
        
  
      });  
      this  
      this.chart = new Chart('pastsale', {  
        type: 'bar',  

        options: {
          responsive: true,
          title: {
            display: true,
            text: 'Past 5 Years Sales'
          },
        },






        data: {  
          labels: this.year,  
          datasets: [  
            // {  
            //   type: 'pie',
          
            // data: this.dipSale,
            // backgroundColor: ["red","orange","yellow","green","blue","purple","red","orange",
            // "yellow","green","blue","purple"],
            //   borderColor: 'rgba(0,0,0,1)',
            // fill: false,
            // }  ,

            {
              type: 'bar',
              label: 'UAE',
              data: this.uae,
              backgroundColor: 'rgba(0,255,0,0.7)',
              borderColor: 'rgba(0,255,255,1)',
              fill: false,
            },

            {
              type: 'bar',
              label: 'US',
              data: this.usa,
              backgroundColor: 'rgba(255,0,0,1)',
              borderColor: 'rgba(0,0,255,1)',
              fill: false,
            },

            {
              type: 'bar',
              label: 'UK',
              data: this.uk,
              backgroundColor: 'rgba(0,0,255,1)',
              borderColor: 'rgba(0,255,0,0.3)',
              fill: false,
            }
          

          ]  
        },  


      });  

  })
}

}
