import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PastsalechartComponent } from './pastsalechart.component';

describe('PastsalechartComponent', () => {
  let component: PastsalechartComponent;
  let fixture: ComponentFixture<PastsalechartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PastsalechartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PastsalechartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
