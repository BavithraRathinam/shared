import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchchartComponent } from './searchchart.component';

describe('SearchchartComponent', () => {
  let component: SearchchartComponent;
  let fixture: ComponentFixture<SearchchartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchchartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchchartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
